# dual_autodiff_x/__init__.py
import numpy as np
from .dual import Dual
__all__ = ['Dual']