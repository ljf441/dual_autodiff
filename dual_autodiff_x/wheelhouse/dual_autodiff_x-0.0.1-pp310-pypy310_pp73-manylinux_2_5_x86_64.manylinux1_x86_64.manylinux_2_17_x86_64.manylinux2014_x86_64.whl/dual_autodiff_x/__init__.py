# dual_autodiff_x/__init__.py
from .dual import Dual
import numpy as np

__all__ = ['Dual']