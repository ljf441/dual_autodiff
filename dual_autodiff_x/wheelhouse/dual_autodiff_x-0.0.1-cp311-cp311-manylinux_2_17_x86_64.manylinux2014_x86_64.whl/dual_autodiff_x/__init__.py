# dual_autodiff_x/__init__.py
import numpy as np
import mpmath as mp
from .dual import Dual, Collection
__all__ = ['Dual', 'Collection']